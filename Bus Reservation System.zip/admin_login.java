public class admin_login {
    private String adminName;  String adminPassword;
    public admin_login(String adminName,String adminPassword) {
        this.adminName = adminName;
        this.adminPassword = adminPassword;
        }


    public String adminName() {
        return adminName;
    }

    public String adminPassword() {
        return adminPassword;
    }
}