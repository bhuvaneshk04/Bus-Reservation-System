import java.sql.*;
import java.util.*;

public class Main {
	static Scanner sc=new Scanner(System.in);
	public static void adminLogin() throws Exception {
		System.out.println("ENTER YOUR USERNAME");
		String user=sc.next();
		System.out.println("ENTER YOUR PASSWORD");
		String pas=sc.next();
		aLogin(user,pas);
	}
	public static void passengerLogin() throws Exception{
		System.out.println("ENTER YOUR USERNAME");
		String user=sc.next();
		System.out.println("ENTER YOUR PASSWORD");
		String pas=sc.next();
		pLogin(user,pas);
	}
	public static void adminReg() throws Exception{
		System.out.println("ENTER YOUR USERNAME");
		String user=sc.next();
		System.out.println("ENTER YOUR PASSWORD");
		String pas=sc.next();
		aRegister(user,pas);
	}
	public static  void passengerReg() throws Exception{
		System.out.println("ENTER YOUR USERNAME");
		String user=sc.next();
		System.out.println("ENTER YOUR PASSWORD");
		String pas=sc.next();
		pRegister(user,pas);
	}
    public static void main(String[] args) throws Exception{
    	Scanner sc = new Scanner(System.in);
    	System.out.println("ENTER 1 FOR ADMIN LOGIN");
    	System.out.println("ENTER 2 FOR ADMIN REGISTERATION");
    	System.out.println("ENTER 3 FOR PASSENGER LOGIN");
    	System.out.println("ENTER 4 FOR PASSENGER REGISTERATION");
    	int log=sc.nextInt();
    	if(log==1) {
    		adminLogin();
    	}
    	else if(log==2) {
    		adminReg();
    	}
    	else if(log==3) {
    		passengerLogin();
    	}
    	else if(log==4) {
    		passengerReg();
    	}
    	
       
        sc.close();
    }
    public static void adminPage() {
    	 try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/busdatabase", "root", "root")) {
             BusDAO busDAO = new BusDAO(conn);
             TicketDAO ticketDAO = new TicketDAO(conn);
             while (true) {
             	System.out.println("Hello,Choose a slot.");
                 System.out.println("1. View available tickets and fare in all buses.");
                 System.out.println("*****************************************************");
                 System.out.println("2. To update source and destination of a bus");
                 System.out.println("*****************************************************");
                 System.out.println("3. View Number of Tickets booked and Verify.");
                 System.out.println("*****************************************************");
                 System.out.println("4. Exit");
                 System.out.println("*****************************************************");
                 System.out.print("Enter your required slot: ");
                 int choice = sc.nextInt();

                 switch (choice) {
                     case 1:
                         List<Bus> buses = busDAO.getAllBuses();
                         for (Bus bus : buses) {
                             System.out.println(bus.getBusId() + " - " + bus.getBusName() + " - " + bus.getSource() + " to " + bus.getDestination() + " - Available Seats: " + bus.getAvailableSeats() + " - Fare: " + bus.getFare());
                         }
                         break;

                     case 2:
                         System.out.print("Enter bus ID: ");
                         int busId = sc.nextInt();
                         System.out.println("ENTER THE UPDATED SOURCE");
                         String sou=sc.next();
                         System.out.println("ENTER THE UPDATED DESTINATION");
                         String des=sc.next();
                         Statement st=conn.createStatement();
                         String Query="update buses set source='"+sou+"',destination='"+des+"' where id="+busId+"";
                         int rs=st.executeUpdate(Query);
                         System.out.println("SUCCESSFULLY UPDATED");
                         break;
                     case 3:
                         System.out.print("Enter bus ID: ");
                         int busId2 = sc.nextInt();
                         List<Ticket> tickets = ticketDAO.getTicketsByBusId(busId2);
                         if (tickets.isEmpty()) {
                             System.out.println("No tickets found for the selected bus");
                             continue;
                         }
                         System.out.println("Tickets for bus " + busId2 + ":");
                         for (Ticket ticket : tickets) {
                             System.out.println(ticket.getTicketId() + " - Passenger Name: " + ticket.getPassengerName() + " - Number of Seats: " + ticket.getNumSeats() + " - Total Fare: " + ticket.getTotalFare());
                         }
                         break;

                     case 4:
                         System.out.println("        Thankyou!          ");
                         System.out.println("*-*___HAPPY JOURNEY___*-*");
                         return;

                     default:
                         System.out.println("Invalid choice, please try again:-(");
                         break;
                 }
             }
         } catch (SQLException ex) {
             System.out.println("An error occurred: " + ex.getMessage());
         }

    }
    public  static void passengerPage() {
    	 try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/busdatabase", "root", "root")) {
             BusDAO busDAO = new BusDAO(conn);
             TicketDAO ticketDAO = new TicketDAO(conn);
             while (true) {
             	System.out.println("Hello,Choose a slot.");
                 System.out.println("1. View available tickets and fare in all buses.");
                 System.out.println("*****************************************************");
                 System.out.println("2. Choose a Bus and Book a ticket.");
                 System.out.println("*****************************************************");
                 System.out.println("3. View Number of Tickets booked and Verify.");
                 System.out.println("*****************************************************");
                 System.out.println("4. Exit");
                 System.out.println("*****************************************************");
                 System.out.print("Enter your required slot: ");
                 int choice = sc.nextInt();

                 switch (choice) {
                     case 1:
                         List<Bus> buses = busDAO.getAllBuses();
                         for (Bus bus : buses) {
                             System.out.println(bus.getBusId() + " - " + bus.getBusName() + " - " + bus.getSource() + " to " + bus.getDestination() + " - Available Seats: " + bus.getAvailableSeats() + " - Fare: " + bus.getFare());
                         }
                         break;

                     case 2:
                         System.out.print("Enter bus ID: ");
                         int busId = sc.nextInt();
                         Bus bus = busDAO.getBusById(busId);
                         if (bus == null) {
                             System.out.println("Bus not found");
                             continue;
                         }
                         System.out.println("Bus selected: " + bus.getBusName() + " - Available Seats: " + bus.getAvailableSeats());

                         System.out.print("Enter passenger name: ");
                         String passengerName = sc.next();

                         System.out.print("Enter number of seats: ");
                         int numSeats = sc.nextInt();

                         double totalFare = bus.getFare() * numSeats;

                         if (numSeats > bus.getAvailableSeats()) {
                             System.out.println("Sorry, there are not enough seats available");
                             continue;
                         }

                         ticketDAO.bookTicket(busId, passengerName, numSeats, totalFare);
                         busDAO.updateBusAvailableSeats(busId, numSeats);
                     case 3:
                         System.out.print("Enter bus ID: ");
                         int busId2 = sc.nextInt();
                         List<Ticket> tickets = ticketDAO.getTicketsByBusId(busId2);
                         if (tickets.isEmpty()) {
                             System.out.println("No tickets found for the selected bus");
                             continue;
                         }
                         System.out.println("Tickets for bus " + busId2 + ":");
                         for (Ticket ticket : tickets) {
                             System.out.println(ticket.getTicketId() + " - Passenger Name: " + ticket.getPassengerName() + " - Number of Seats: " + ticket.getNumSeats() + " - Total Fare: " + ticket.getTotalFare());
                         }
                         break;

                     case 4:
                         System.out.println("        Thankyou!          ");
                         System.out.println("*-*___HAPPY JOURNEY___*-*");
                         return;

                     default:
                         System.out.println("Invalid choice, please try again:-(");
                         break;
                 }
             }
         } catch (SQLException ex) {
             System.out.println("An error occurred: " + ex.getMessage());
         }
    }
    public static void aRegister(String user,String pass) throws Exception {
    	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/busdatabase", "root", "root");
    	Statement st=con.createStatement();
    	String  Query="insert into admin values('"+user+"','"+pass+"')";
    	int rs=st.executeUpdate(Query);
    	System.out.println("SUCCESSFULLY ADDED AS A NEW ADMIN");
    }
    public static void  aLogin(String user,String pass) throws Exception{
    	boolean flag=false;
    	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/busdatabase", "root", "root");
    	Statement st=con.createStatement();
    	String Query="select * from admin";
    	ResultSet rs=st.executeQuery(Query);
    	while(rs.next()) {
    		if(rs.getString(1).equals(user) && rs.getString(2).equals(pass)) {
    			System.out.println("VERIFIED");
    			adminPage();
    			flag=true;
    			break;
    		}
    	}
    	if(flag==false) {
    		System.out.println("ENTERED USERNAME OR PASSWORD IS INVALID");
    	}
    }
    public static void pRegister(String user,String pass) throws Exception{
    	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/busdatabase", "root", "root");
    	Statement st=con.createStatement();
    	String Query="insert into passenger values('"+user+"','"+pass+"')";
    	int rs=st.executeUpdate(Query);
    	System.out.println("YOUR ACCOUNT IS SUCCESSFULLY CREATED");
    }
    public static void pLogin(String user,String  pass) throws Exception{
    	boolean flag=false;
    	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/busdatabase", "root", "root");
    	Statement st=con.createStatement();
    	String Query="select  * from passenger";
    	ResultSet rs=st.executeQuery(Query);
    	while(rs.next()) {
    		if(rs.getString(1).equals(user) && rs.getString(2).equals(pass)) {
    			System.out.println("VERIFIED");
    			passengerPage();
    			flag=true;
    			break;
    		}
    	}
    	if(flag==false) {
    		System.out.println("ENTERED USERNAME OR PASSWORD IS INVALID");
    	}
    }
}