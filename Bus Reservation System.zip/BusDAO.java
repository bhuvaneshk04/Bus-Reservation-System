import java.sql.*;
import java.util.*;
public class BusDAO {
    private Connection conn;

    public BusDAO(Connection conn) {
        this.conn = conn;
    }

    public List<Bus> getAllBuses() throws SQLException {
        List<Bus> buses = new ArrayList<>();
        String sql = "SELECT * FROM buses";
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                int busId = rs.getInt("id");
                String busName = rs.getString("bus_name");
                String source = rs.getString("source");
                String destination = rs.getString("destination");
                int availableSeats = rs.getInt("available_seats");
                double fare = rs.getDouble("fare");
                buses.add(new Bus(busId, busName, source, destination, availableSeats, fare));
            }
        }
        return buses;
    }

    public Bus getBusById(int busId) throws SQLException {
        String sql = "SELECT * FROM buses WHERE id=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, busId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    String busName = rs.getString("bus_name");
                    String source = rs.getString("source");
                    String destination = rs.getString("destination");
                    int availableSeats = rs.getInt("available_seats");
                    double fare = rs.getDouble("fare");
                    return new Bus(busId, busName, source, destination, availableSeats, fare);
                }
            }
        }
        return null;
    }

    public void updateBusAvailableSeats(int busId, int numSeats) throws SQLException {
        String sql = "UPDATE buses SET available_seats = available_seats - ? WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, numSeats);
            stmt.setInt(2, busId);
            stmt.executeUpdate();
        }
    }
public void TicketDAO(Connection conn) {
        this.conn = conn;
        }
        }