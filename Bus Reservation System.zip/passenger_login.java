public class passenger_login {
    private String passengerName;
    private String passengerPassword;
    public passenger_login(String passengerName,String passengerPassword) {
        this.passengerName = adminName();
        this.passengerPassword = adminPassword( );
        }


    public String adminName() {
        return passengerName;
    }

    public String adminPassword() {
        return passengerPassword;
    }
}