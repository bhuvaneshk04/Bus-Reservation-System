import java.sql.*;
import java.util.*;

public class TicketDAO {
    private Connection conn;

    public TicketDAO(Connection conn) {
        this.conn = conn;
    }

    public void bookTicket(int busId, String passengerName, int numSeats, double totalFare) {
        String sql = "INSERT INTO tickets (id, passenger_name, num_seats, total_fare) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, busId);
            stmt.setString(2, passengerName);
            stmt.setInt(3, numSeats);
            stmt.setDouble(4, totalFare);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public List<Ticket> getTicketsByBusId(int busId) throws SQLException {
        List<Ticket> tickets = new ArrayList<>();
        String sql = "SELECT * FROM tickets WHERE id=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, busId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    int ticketId = rs.getInt("ticket_id");
                    String passengerName = rs.getString("passenger_name");
                    int numSeats = rs.getInt("num_seats");
                    double totalFare = rs.getDouble("total_fare");
                    tickets.add(new Ticket(ticketId, busId, passengerName, numSeats, totalFare));
                }
            }
        }
        return tickets;
    }
}