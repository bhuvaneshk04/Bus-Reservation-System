
public class Ticket {
    private int ticketId;
    private int busId;
    private String passengerName;
    private int numSeats;
    private double totalFare;

    public Ticket(int ticketId, int busId, String passengerName, int numSeats, double totalFare) {
        this.ticketId = ticketId;
        this.busId = busId;
        this.passengerName = passengerName;
        this.numSeats = numSeats;
        this.totalFare = totalFare;
    }

    public int getTicketId() {
        return ticketId;
    }

    public int getBusId() {
        return busId;
    }

    public String getPassengerName() {
        return passengerName;
    }

    public int getNumSeats() {
        return numSeats;
    }

    public double getTotalFare() {
        return totalFare;
    }
}